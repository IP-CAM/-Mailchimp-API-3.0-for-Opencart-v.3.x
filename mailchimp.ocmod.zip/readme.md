### Description

It module helps the Opencart admins to integrate and manage your ecommerce data with Mailchimp API 3.0 (ecommerce data only).

### Compatible With
1. It only works with 3.0.x OpernCart

### Warning

1. It's a alpha module. You should not install it in production stores.
2. It doesn't work with multistore (will synchronize only default store data).

